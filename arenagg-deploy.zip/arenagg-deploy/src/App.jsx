import { useState, useEffect, useCallback } from 'react'
import supabase from './lib/supabase.js'

// ── CONSTANTS ─────────────────────────────────────────────────────────────────
const GAMES   = ['Mobile Legends','PUBG Mobile','Free Fire','Valorant','Clash Royale']
const FORMATS = ['Single Elimination','Double Elimination','Round Robin','Swiss']
const fmtRp   = n => 'Rp ' + Number(n).toLocaleString('id-ID')
const uid     = () => crypto.randomUUID()

const NAV = [
  { id:'dashboard',   icon:'⚡', label:'Dashboard'  },
  { id:'revenue',     icon:'📈', label:'Komisi'      },
  { id:'tournaments', icon:'🏆', label:'Turnamen'    },
  { id:'create',      icon:'＋', label:'Buat'        },
  { id:'teams',       icon:'👥', label:'Peserta'     },
  { id:'bracket',     icon:'📊', label:'Bracket'     },
  { id:'finance',     icon:'💰', label:'Keuangan'    },
  { id:'settings',    icon:'⚙',  label:'Setting'     },
]

// ── GLOBAL CSS ────────────────────────────────────────────────────────────────
const css = `
  *{margin:0;padding:0;box-sizing:border-box;}
  :root{
    --bg:#050508;--bg2:#0d0d14;--bg3:#12121c;--panel:#161622;--border:#1e1e30;
    --cyan:#00e5ff;--orange:#ff6b00;--green:#00ff88;--red:#ff2d55;--yellow:#ffd700;
    --text:#e8e8f0;--muted:#5a5a7a;
    --fh:'Orbitron',sans-serif;--fb:'Rajdhani',sans-serif;--fm:'Share Tech Mono',monospace;
    --sidebar:230px;
  }
  body{background:var(--bg);color:var(--text);font-family:var(--fb);}
  ::-webkit-scrollbar{width:4px;}
  ::-webkit-scrollbar-track{background:var(--bg2);}
  ::-webkit-scrollbar-thumb{background:var(--cyan);border-radius:2px;}
  @keyframes slide-in{from{opacity:0;transform:translateY(14px);}to{opacity:1;transform:translateY(0);}}
  @keyframes glow-pulse{0%,100%{text-shadow:0 0 8px var(--cyan),0 0 20px var(--cyan);}50%{text-shadow:0 0 4px var(--cyan);}}
  @keyframes flicker{0%,19%,21%,25%,54%,56%,100%{opacity:1;}20%,24%,55%{opacity:0.4;}}
  @keyframes bar-fill{from{width:0;}}
  @keyframes spin{to{transform:rotate(360deg);}}
  @keyframes pop-in{from{opacity:0;transform:scale(0.94);}to{opacity:1;transform:scale(1);}}
  @keyframes bounce-in{0%{transform:translateY(50px);opacity:0;}60%{transform:translateY(-6px);}100%{transform:translateY(0);opacity:1;}}
  @keyframes pulse{0%,100%{opacity:1;}50%{opacity:0.5;}}
  .animate-in{animation:slide-in 0.32s ease both;}
  .pop-in{animation:pop-in 0.22s ease both;}
  .btn{display:inline-flex;align-items:center;gap:7px;padding:10px 20px;border:none;border-radius:5px;font-family:var(--fh);font-size:11px;font-weight:700;letter-spacing:1px;cursor:pointer;transition:all 0.18s;text-transform:uppercase;}
  .btn:disabled{opacity:0.5;cursor:not-allowed;}
  .btn-cyan{background:var(--cyan);color:#000;}.btn-cyan:not(:disabled):hover{box-shadow:0 0 18px var(--cyan);transform:translateY(-1px);}
  .btn-orange{background:var(--orange);color:#fff;}.btn-orange:not(:disabled):hover{box-shadow:0 0 18px var(--orange);}
  .btn-ghost{background:transparent;color:var(--cyan);border:1px solid var(--cyan);}.btn-ghost:not(:disabled):hover{background:rgba(0,229,255,0.08);}
  .btn-danger{background:var(--red);color:#fff;}
  .btn-green{background:var(--green);color:#000;}
  .btn-dark{background:var(--panel);color:var(--text);border:1px solid var(--border);}
  .btn-sm{padding:6px 13px;font-size:10px;}
  .btn-full{width:100%;justify-content:center;}
  .card{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:20px;position:relative;overflow:hidden;}
  .card::before{content:'';position:absolute;top:0;left:0;right:0;height:1px;background:linear-gradient(90deg,transparent,var(--cyan),transparent);opacity:0.3;}
  .tag{display:inline-block;padding:2px 9px;border-radius:2px;font-family:var(--fm);font-size:10px;text-transform:uppercase;letter-spacing:1px;}
  .tag-active{background:rgba(0,255,136,0.13);color:var(--green);border:1px solid rgba(0,255,136,0.28);}
  .tag-pending{background:rgba(255,215,0,0.1);color:var(--yellow);border:1px solid rgba(255,215,0,0.28);}
  .tag-closed{background:rgba(90,90,122,0.18);color:var(--muted);border:1px solid var(--border);}
  .tag-live{background:rgba(255,45,85,0.13);color:var(--red);border:1px solid rgba(255,45,85,0.28);animation:flicker 3s infinite;}
  input,select,textarea{background:var(--bg3);border:1px solid var(--border);border-radius:4px;color:var(--text);font-family:var(--fb);font-size:15px;padding:10px 14px;width:100%;outline:none;transition:border-color 0.18s;}
  input:focus,select:focus,textarea:focus{border-color:var(--cyan);box-shadow:0 0 0 2px rgba(0,229,255,0.09);}
  input::placeholder,textarea::placeholder{color:var(--muted);}
  label{display:block;font-size:11px;font-family:var(--fm);color:var(--muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:0.5px;}
  .g2{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
  .g3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px;}
  .g4{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;}
  @media(max-width:900px){.g4{grid-template-columns:1fr 1fr;}.g3{grid-template-columns:1fr 1fr;}}
  @media(max-width:600px){.g2,.g3,.g4{grid-template-columns:1fr;}}
  hr.div{border:none;border-top:1px solid var(--border);margin:18px 0;}
  .pbar{height:5px;background:var(--bg3);border-radius:3px;overflow:hidden;}
  .pfill{height:100%;border-radius:3px;animation:bar-fill 0.7s ease;}
  .sidebar{width:var(--sidebar);min-width:var(--sidebar);background:var(--bg2);border-right:1px solid var(--border);display:flex;flex-direction:column;height:100vh;position:sticky;top:0;z-index:100;}
  .nav-item{display:flex;align-items:center;gap:9px;padding:10px 14px;border-radius:4px;cursor:pointer;font-family:var(--fb);font-size:14px;font-weight:500;color:var(--muted);transition:all 0.18s;border:none;background:none;width:100%;text-align:left;}
  .nav-item:hover{color:var(--text);background:rgba(255,255,255,0.04);}
  .nav-item.active{color:var(--cyan);background:rgba(0,229,255,0.08);border-left:2px solid var(--cyan);padding-left:12px;}
  .nav-icon{font-size:17px;width:20px;text-align:center;flex-shrink:0;}
  .bottom-nav{display:none;position:fixed;bottom:0;left:0;right:0;background:var(--bg2);border-top:1px solid var(--border);z-index:200;padding:6px 0;grid-template-columns:repeat(8,1fr);}
  .bnav-item{display:flex;flex-direction:column;align-items:center;gap:2px;padding:5px 2px;border:none;background:none;cursor:pointer;color:var(--muted);font-family:var(--fm);font-size:7px;text-transform:uppercase;transition:color 0.15s;flex:1;}
  .bnav-item.active{color:var(--cyan);}
  .bnav-icon{font-size:17px;line-height:1;}
  .toast-wrap{position:fixed;bottom:80px;right:16px;z-index:9999;display:flex;flex-direction:column;gap:7px;}
  @media(min-width:769px){.toast-wrap{bottom:24px;}}
  .toast{background:var(--panel);border:1px solid var(--border);border-radius:5px;padding:11px 16px;font-size:14px;animation:slide-in 0.28s ease;display:flex;align-items:center;gap:9px;max-width:300px;}
  .toast-success{border-left:3px solid var(--green);}
  .toast-error{border-left:3px solid var(--red);}
  .toast-info{border-left:3px solid var(--cyan);}
  .overlay{position:fixed;inset:0;background:rgba(0,0,0,0.88);backdrop-filter:blur(4px);z-index:500;display:flex;align-items:center;justify-content:center;padding:16px;}
  .modal{background:var(--bg2);border:1px solid var(--border);border-radius:8px;padding:24px;width:100%;max-width:540px;max-height:92vh;overflow-y:auto;animation:pop-in 0.22s ease;}
  .link-box{background:var(--bg3);border:1px solid var(--border);border-radius:4px;padding:10px 14px;display:flex;align-items:center;gap:10px;font-family:var(--fm);font-size:12px;color:var(--cyan);word-break:break-all;}
  .auth-bg{min-height:100vh;background:var(--bg);display:flex;align-items:center;justify-content:center;padding:20px;background-image:radial-gradient(ellipse at 20% 50%,rgba(0,229,255,0.04) 0%,transparent 60%),radial-gradient(ellipse at 80% 20%,rgba(255,107,0,0.04) 0%,transparent 60%);}
  .auth-card{background:var(--bg2);border:1px solid var(--border);border-radius:10px;padding:36px 32px;width:100%;max-width:440px;animation:pop-in 0.3s ease;}
  .live-dot{width:8px;height:8px;border-radius:50%;background:var(--green);animation:pulse 1.5s infinite;display:inline-block;margin-right:6px;vertical-align:middle;}
  .b-match{background:var(--panel);border:1px solid var(--border);border-radius:4px;width:170px;overflow:hidden;}
  .b-team{padding:8px 11px;font-size:12px;font-weight:600;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);}
  .b-team:last-child{border-bottom:none;}
  .b-team.winner{background:rgba(0,255,136,0.08);color:var(--green);}
  .b-team.loser{color:var(--muted);}
  @media(max-width:768px){
    .sidebar{display:none;}
    .bottom-nav{display:grid;}
    main{padding-bottom:80px;}
    .hide-mobile{display:none !important;}
  }
  @media(min-width:769px){.bottom-nav{display:none !important;}}
`
const styleEl = document.createElement('style')
styleEl.textContent = css
document.head.appendChild(styleEl)

// ── HELPERS ───────────────────────────────────────────────────────────────────
function Spinner({ size = 18, color = 'currentColor' }) {
  return <span style={{ width: size, height: size, border: `2px solid rgba(255,255,255,0.2)`, borderTopColor: color, borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block', flexShrink: 0 }} />
}

function Toasts({ list }) {
  return (
    <div className="toast-wrap">
      {list.map(t => (
        <div key={t.id} className={`toast toast-${t.type}`}>
          <span>{t.type === 'success' ? '✓' : t.type === 'error' ? '✗' : 'ℹ'}</span>
          <span>{t.msg}</span>
        </div>
      ))}
    </div>
  )
}

function StatCard({ icon, label, value, sub, color = '#00e5ff', trend }) {
  return (
    <div className="card">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: 10, fontFamily: 'var(--fm)', color: 'var(--muted)', letterSpacing: 1, textTransform: 'uppercase', marginBottom: 7 }}>{label}</div>
          <div style={{ fontSize: 24, fontFamily: 'var(--fh)', fontWeight: 900, color, lineHeight: 1 }}>{value}</div>
          {sub && <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 5 }}>{sub}</div>}
        </div>
        <div style={{ fontSize: 24, opacity: 0.65 }}>{icon}</div>
      </div>
      {trend !== undefined && <div style={{ marginTop: 10, fontSize: 11, color: trend >= 0 ? 'var(--green)' : 'var(--red)' }}>{trend >= 0 ? '▲' : '▼'} {Math.abs(trend)}% bulan ini</div>}
    </div>
  )
}

function QRCode({ value, size = 120 }) {
  const seed = value.split('').reduce((a, c) => a + c.charCodeAt(0), 0)
  const cells = 21; const cell = size / cells
  const grid = Array.from({ length: cells }, (_, r) =>
    Array.from({ length: cells }, (_, c) => {
      if ((r < 7 && c < 7) || (r < 7 && c > 13) || (r > 13 && c < 7)) return 1
      return ((seed * r * 31 + c * 17) % 7 < 3) ? 1 : 0
    })
  )
  return (
    <svg width={size} height={size} style={{ background: 'white', borderRadius: 4, display: 'block' }}>
      {grid.map((row, r) => row.map((v, c) => v ? <rect key={`${r}-${c}`} x={c * cell} y={r * cell} width={cell} height={cell} fill="black" /> : null))}
    </svg>
  )
}

// ── AUTH PAGE ─────────────────────────────────────────────────────────────────
function AuthPage({ onLogin }) {
  const [mode, setMode]   = useState('login')
  const [email, setEmail] = useState('')
  const [pass, setPass]   = useState('')
  const [name, setName]   = useState('')
  const [loading, setL]   = useState(false)
  const [err, setErr]     = useState('')

  const submit = async () => {
    setErr(''); setL(true)
    try {
      if (mode === 'login') {
        const { data, error } = await supabase.auth.signInWithPassword({ email, password: pass })
        if (error) throw error
        onLogin(data.user)
      } else {
        const { data, error } = await supabase.auth.signUp({
          email, password: pass,
          options: { data: { organizer_name: name || email.split('@')[0] } }
        })
        if (error) throw error
        if (data.user && !data.session) {
          setErr('Cek email kamu untuk konfirmasi, lalu login.')
          setMode('login')
        } else if (data.user) {
          onLogin(data.user)
        }
      }
    } catch (e) {
      setErr(e.message || 'Terjadi kesalahan.')
    }
    setL(false)
  }

  return (
    <div className="auth-bg">
      <div style={{ width: '100%', maxWidth: 400 }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontFamily: 'var(--fh)', fontSize: 26, fontWeight: 900, color: 'var(--cyan)', letterSpacing: 3, animation: 'glow-pulse 3s infinite' }}>⚔ ARENAGG</div>
          <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 4, fontFamily: 'var(--fm)' }}>Esport Tournament Platform</div>
        </div>
        <div className="auth-card">
          <div style={{ display: 'flex', background: 'var(--bg3)', borderRadius: 5, padding: 3, marginBottom: 22 }}>
            {[{ id: 'login', label: 'Masuk' }, { id: 'register', label: 'Daftar Organizer' }].map(t => (
              <button key={t.id} onClick={() => { setMode(t.id); setErr('') }} style={{ flex: 1, padding: 8, border: 'none', borderRadius: 4, cursor: 'pointer', fontFamily: 'var(--fh)', fontSize: 10, letterSpacing: 1, transition: 'all 0.18s', background: mode === t.id ? 'var(--cyan)' : 'transparent', color: mode === t.id ? '#000' : 'var(--muted)' }}>{t.label}</button>
            ))}
          </div>
          {mode === 'register' && <div style={{ marginBottom: 14 }}><label>Nama Komunitas</label><input value={name} onChange={e => setName(e.target.value)} placeholder="GamingID Org" /></div>}
          <div style={{ marginBottom: 14 }}><label>Email</label><input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="kamu@email.com" /></div>
          <div style={{ marginBottom: 20 }}><label>Password</label><input type="password" value={pass} onChange={e => setPass(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === 'Enter' && submit()} /></div>
          {err && <div style={{ color: 'var(--red)', fontSize: 12, marginBottom: 14, padding: '10px 12px', background: 'rgba(255,45,85,0.08)', borderRadius: 4 }}>⚠ {err}</div>}
          <button className="btn btn-cyan btn-full" onClick={submit} disabled={!email || !pass || loading} style={{ fontSize: 13, padding: 13 }}>
            {loading ? <><Spinner size={13} color="#000" /> Memproses...</> : mode === 'login' ? '🔑 Masuk' : '🚀 Buat Akun'}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── DATA HOOKS ────────────────────────────────────────────────────────────────
function useData(userId, toast) {
  const [tournaments, setT]  = useState([])
  const [teams, setTeams]    = useState([])
  const [loading, setL]      = useState(true)

  const load = useCallback(async () => {
    if (!userId) { setL(false); return }
    setL(true)
    try {
      const [{ data: ts }, { data: tms }] = await Promise.all([
        supabase.from('tournaments').select('*').eq('organizer_id', userId).order('created_at', { ascending: false }),
        supabase.from('teams').select('*, tournaments!inner(organizer_id)').eq('tournaments.organizer_id', userId),
      ])
      setT(ts || [])
      setTeams((tms || []).map(({ tournaments: _, ...rest }) => rest))
    } catch (e) {
      toast('Gagal load data: ' + e.message, 'error')
    }
    setL(false)
  }, [userId])

  useEffect(() => { load() }, [load])

  // Realtime subscription
  useEffect(() => {
    if (!userId) return
    const ch = supabase.channel('db')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'tournaments' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'teams' }, load)
      .subscribe()
    return () => supabase.removeChannel(ch)
  }, [userId, load])

  const addT = async data => {
    const { error } = await supabase.from('tournaments').insert({ ...data, organizer_id: userId })
    if (error) { toast('Gagal: ' + error.message, 'error'); return }
    toast('Turnamen dibuat! 🚀', 'success'); await load()
  }
  const updateT = async (id, data) => {
    const { error } = await supabase.from('tournaments').update(data).eq('id', id).eq('organizer_id', userId)
    if (error) { toast('Gagal: ' + error.message, 'error'); return }
    await load()
  }
  const deleteT = async id => {
    await supabase.from('tournaments').delete().eq('id', id).eq('organizer_id', userId)
    toast('Dihapus', 'info'); await load()
  }
  const addTeam = async data => {
    const { error } = await supabase.from('teams').insert(data)
    if (error) { toast('Gagal: ' + error.message, 'error'); return }
    const cnt = teams.filter(t => t.tournament_id === data.tournament_id).length + 1
    await supabase.from('tournaments').update({ registered: cnt }).eq('id', data.tournament_id)
    toast('Tim didaftarkan! ✅', 'success'); await load()
  }
  const updateTeam = async (id, data) => {
    await supabase.from('teams').update(data).eq('id', id); await load()
  }
  const deleteTeam = async (id, tid) => {
    await supabase.from('teams').delete().eq('id', id)
    const cnt = teams.filter(t => t.tournament_id === tid && t.id !== id).length
    await supabase.from('tournaments').update({ registered: cnt }).eq('id', tid)
    toast('Tim dihapus', 'info'); await load()
  }

  return { tournaments, teams, loading, reload: load, addT, updateT, deleteT, addTeam, updateTeam, deleteTeam }
}

// ── SHARE MODAL ───────────────────────────────────────────────────────────────
function ShareModal({ t, onClose, toast, onPreview }) {
  const link = `${window.location.origin}/#/daftar/${t.id}`
  const wa = encodeURIComponent(`🎮 *${t.name}*\n📍 ${t.city}\n🏆 Prize: ${fmtRp(t.prize)}\n🎫 Entry: ${fmtRp(t.entry)}/tim\n\n👉 Daftar: ${link}`)
  const copy = () => navigator.clipboard.writeText(link).then(() => toast('Link disalin! ✓', 'success'))
  return (
    <div className="overlay" onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <div style={{ fontFamily: 'var(--fh)', fontSize: 13, color: 'var(--cyan)', letterSpacing: 1 }}>🔗 BAGIKAN TURNAMEN</div>
          <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 22 }}>×</button>
        </div>
        <div style={{ background: 'linear-gradient(135deg,rgba(0,229,255,0.08),rgba(255,107,0,0.06))', border: '1px solid rgba(0,229,255,0.2)', borderRadius: 6, padding: '13px 15px', marginBottom: 16 }}>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{t.name}</div>
          <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>{t.game} · {t.city}</div>
          <div style={{ fontSize: 12, color: 'var(--yellow)', marginTop: 2 }}>🏆 {fmtRp(t.prize)} · Entry {fmtRp(t.entry)}/tim</div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, marginBottom: 16, padding: 16, background: 'var(--bg3)', borderRadius: 6 }}>
          <QRCode value={link} size={130} />
          <div style={{ fontSize: 11, color: 'var(--muted)', fontFamily: 'var(--fm)' }}>Scan → halaman daftar peserta</div>
        </div>
        <div style={{ marginBottom: 14 }}>
          <label>Link Pendaftaran</label>
          <div className="link-box" style={{ border: '1px solid var(--cyan)' }}>
            <span style={{ flex: 1, fontSize: 11 }}>{link}</span>
            <button className="btn btn-cyan" style={{ padding: '4px 10px', fontSize: 9, flexShrink: 0 }} onClick={copy}>Salin</button>
          </div>
          <div style={{ fontSize: 11, color: 'var(--green)', marginTop: 4 }}>✓ Link ini membuka halaman peserta — terpisah dari admin</div>
        </div>
        <button onClick={() => { onClose(); onPreview(t.id) }} className="btn btn-ghost btn-full" style={{ marginBottom: 12 }}>👁 Preview Halaman Peserta</button>
        <div style={{ display: 'flex', gap: 8 }}>
          <a href={`https://wa.me/?text=${wa}`} target="_blank" rel="noreferrer" style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 10, background: '#25D366', borderRadius: 5, color: 'white', textDecoration: 'none', fontWeight: 700, fontFamily: 'var(--fh)', fontSize: 10 }}>📱 WhatsApp</a>
          <a href={`https://t.me/share/url?url=${encodeURIComponent(link)}`} target="_blank" rel="noreferrer" style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 10, background: '#229ED9', borderRadius: 5, color: 'white', textDecoration: 'none', fontWeight: 700, fontFamily: 'var(--fh)', fontSize: 10 }}>✈ Telegram</a>
          <button onClick={copy} style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6, padding: 10, background: 'var(--panel)', borderRadius: 5, border: '1px solid var(--border)', color: 'var(--text)', cursor: 'pointer', fontWeight: 700, fontFamily: 'var(--fh)', fontSize: 10 }}>🔗 Copy</button>
        </div>
      </div>
    </div>
  )
}

// ── PUBLIC PAGE (halaman peserta) ─────────────────────────────────────────────
function PublicPage({ tid, onBack, toast }) {
  const [t, setT]         = useState(null)
  const [teams, setTms]   = useState([])
  const [loading, setL]   = useState(true)
  const [step, setStep]   = useState('detail')
  const [form, setForm]   = useState({ name: '', captain: '', contact: '', members: '5' })
  const [saving, setSaving] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))

  useEffect(() => {
    const load = async () => {
      const [{ data: td }, { data: tms }] = await Promise.all([
        supabase.from('tournaments').select('*').eq('id', tid).single(),
        supabase.from('teams').select('*').eq('tournament_id', tid).order('created_at'),
      ])
      setT(td); setTms(tms || []); setL(false)
    }
    load()
  }, [tid])

  const submit = async () => {
    if (!form.name || !form.captain || !form.contact) { toast('Isi semua data!', 'error'); return }
    setSaving(true)
    const { error } = await supabase.from('teams').insert({ tournament_id: tid, name: form.name, captain: form.captain, contact: form.contact, members: Number(form.members), paid: false })
    if (error) { toast('Gagal: ' + error.message, 'error'); setSaving(false); return }
    await supabase.from('tournaments').update({ registered: (t?.registered || 0) + 1 }).eq('id', tid)
    setStep('success'); setSaving(false); toast('Pendaftaran berhasil! 🎉', 'success')
  }

  if (loading) return <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Spinner size={36} color="var(--cyan)" /></div>
  if (!t) return <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}><div style={{ textAlign: 'center' }}><div style={{ fontSize: 52, marginBottom: 12 }}>😕</div><div style={{ fontFamily: 'var(--fh)', fontSize: 16, color: 'var(--red)', marginBottom: 8 }}>TURNAMEN TIDAK DITEMUKAN</div><button className="btn btn-ghost" onClick={onBack}>← Kembali</button></div></div>

  const slotsLeft = t.slots - (t.registered || 0)
  const fillPct   = Math.round(((t.registered || 0) / t.slots) * 100)
  const isFull    = slotsLeft <= 0

  return (
    <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
      <div style={{ background: 'var(--bg2)', borderBottom: '1px solid var(--border)', padding: '11px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontFamily: 'var(--fh)', fontSize: 15, color: 'var(--cyan)', letterSpacing: 2, fontWeight: 900 }}>⚔ ARENAGG</div>
        <button onClick={onBack} style={{ background: 'none', border: '1px solid var(--border)', borderRadius: 4, padding: '5px 12px', color: 'var(--muted)', cursor: 'pointer', fontSize: 11, fontFamily: 'var(--fm)' }}>← Admin</button>
      </div>
      <div style={{ maxWidth: 560, margin: '0 auto', padding: '20px 16px' }}>
        {step === 'detail' && (
          <div className="animate-in">
            <div style={{ background: 'linear-gradient(135deg,rgba(0,229,255,0.1),rgba(255,107,0,0.08))', border: '1px solid rgba(0,229,255,0.25)', borderRadius: 10, padding: '26px 20px', marginBottom: 16, textAlign: 'center' }}>
              <span className={`tag tag-${t.status}`} style={{ marginBottom: 10, display: 'inline-block' }}>{t.status}</span>
              <div style={{ fontFamily: 'var(--fh)', fontSize: 20, fontWeight: 900, marginBottom: 6 }}>{t.name}</div>
              <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 12 }}>🎮 {t.game} · 📍 {t.city}</div>
              <div style={{ fontFamily: 'var(--fh)', fontSize: 28, color: 'var(--yellow)', fontWeight: 900 }}>{fmtRp(t.prize)}</div>
              <div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 4 }}>Total Prize Pool</div>
            </div>
            <div className="g2" style={{ marginBottom: 14 }}>
              {[{ icon: '🎫', label: 'Entry Fee', value: fmtRp(t.entry) + '/tim' }, { icon: '📅', label: 'Tanggal', value: t.date }, { icon: '⚙', label: 'Format', value: t.format }, { icon: '👥', label: 'Slot Tersisa', value: `${slotsLeft}/${t.slots}`, color: slotsLeft <= 3 ? 'var(--red)' : 'var(--green)' }].map(d => (
                <div key={d.label} className="card" style={{ padding: '12px 14px', display: 'flex', gap: 10, alignItems: 'center' }}>
                  <span style={{ fontSize: 20 }}>{d.icon}</span>
                  <div><div style={{ fontSize: 10, fontFamily: 'var(--fm)', color: 'var(--muted)' }}>{d.label}</div><div style={{ fontSize: 14, fontWeight: 600, color: d.color || 'var(--text)', marginTop: 2 }}>{d.value}</div></div>
                </div>
              ))}
            </div>
            <div className="card" style={{ marginBottom: 14 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 12 }}><span style={{ color: 'var(--muted)' }}>Slot Terisi</span><span style={{ fontFamily: 'var(--fm)', color: fillPct >= 90 ? 'var(--red)' : 'var(--cyan)' }}>{t.registered || 0}/{t.slots}</span></div>
              <div className="pbar" style={{ height: 8 }}><div className="pfill" style={{ width: `${fillPct}%`, background: fillPct >= 90 ? 'var(--red)' : fillPct >= 70 ? 'var(--orange)' : 'var(--cyan)' }} /></div>
            </div>
            {t.description && <div className="card" style={{ marginBottom: 14 }}><div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--muted)', marginBottom: 7 }}>TENTANG</div><div style={{ fontSize: 13, lineHeight: 1.7 }}>{t.description}</div></div>}
            {teams.length > 0 && (
              <div className="card" style={{ marginBottom: 16 }}>
                <div style={{ fontFamily: 'var(--fm)', fontSize: 10, color: 'var(--muted)', marginBottom: 10 }}>TIM TERDAFTAR ({teams.length})</div>
                {teams.map((tm, i) => <div key={tm.id} style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '7px 0', borderBottom: i < teams.length - 1 ? '1px solid var(--border)' : 'none' }}><div style={{ width: 24, height: 24, borderRadius: '50%', background: 'linear-gradient(135deg,var(--cyan),var(--orange))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, fontWeight: 700, color: '#000' }}>{i + 1}</div><span style={{ fontSize: 13, fontWeight: 600 }}>{tm.name}</span>{tm.paid && <span style={{ fontSize: 10, color: 'var(--green)', fontFamily: 'var(--fm)', marginLeft: 'auto' }}>✓ LUNAS</span>}</div>)}
              </div>
            )}
            {t.status === 'closed'
              ? <div style={{ background: 'rgba(90,90,122,0.15)', border: '1px solid var(--border)', borderRadius: 6, padding: 20, textAlign: 'center', color: 'var(--muted)' }}><div style={{ fontSize: 24, marginBottom: 8 }}>🔒</div><div style={{ fontFamily: 'var(--fh)', fontSize: 12 }}>PENDAFTARAN DITUTUP</div></div>
              : <button className="btn btn-cyan btn-full" style={{ fontSize: 14, padding: 13, opacity: isFull ? 0.4 : 1 }} onClick={() => !isFull && setStep('form')} disabled={isFull}>{isFull ? '❌ Slot Penuh' : '✅ Daftar Tim Sekarang →'}</button>}
          </div>
        )}
        {step === 'form' && (
          <div className="animate-in">
            <button onClick={() => setStep('detail')} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 13, marginBottom: 16 }}>← Kembali</button>
            <div style={{ fontFamily: 'var(--fh)', fontSize: 17, fontWeight: 700, marginBottom: 3, color: 'var(--cyan)' }}>DAFTARKAN TIM</div>
            <div style={{ fontSize: 13, color: 'var(--muted)', marginBottom: 16 }}>{t.name}</div>
            <div className="card">
              <div style={{ marginBottom: 13 }}><label>Nama Tim *</label><input value={form.name} onChange={set('name')} placeholder="Alpha Squad" /></div>
              <div className="g2" style={{ marginBottom: 13 }}><div><label>Kapten *</label><input value={form.captain} onChange={set('captain')} placeholder="Nama kapten" /></div><div><label>No. HP *</label><input value={form.contact} onChange={set('contact')} placeholder="08xx" type="tel" /></div></div>
              <div style={{ marginBottom: 18 }}><label>Jumlah Member</label><select value={form.members} onChange={set('members')}>{[1, 2, 3, 4, 5, 6].map(n => <option key={n}>{n}</option>)}</select></div>
              <div style={{ background: 'rgba(255,215,0,0.07)', border: '1px solid rgba(255,215,0,0.2)', borderRadius: 4, padding: '11px 14px', marginBottom: 18, fontSize: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}><span style={{ color: 'var(--muted)' }}>Entry Fee</span><span style={{ fontFamily: 'var(--fm)', color: 'var(--yellow)', fontWeight: 700 }}>{fmtRp(t.entry)}</span></div>
              </div>
              <button className="btn btn-cyan btn-full" style={{ fontSize: 13, padding: 13 }} onClick={submit} disabled={saving}>{saving ? <><Spinner size={13} color="#000" />Mendaftarkan...</> : '🚀 Kirim Pendaftaran'}</button>
            </div>
          </div>
        )}
        {step === 'success' && (
          <div className="animate-in" style={{ textAlign: 'center', paddingTop: 36 }}>
            <div style={{ fontSize: 60, marginBottom: 14, animation: 'bounce-in 0.6s ease' }}>🎉</div>
            <div style={{ fontFamily: 'var(--fh)', fontSize: 20, fontWeight: 900, color: 'var(--green)', marginBottom: 8 }}>PENDAFTARAN BERHASIL!</div>
            <div style={{ fontSize: 14, color: 'var(--muted)', marginBottom: 20, lineHeight: 1.7 }}>Tim <b style={{ color: 'var(--cyan)' }}>{form.name}</b> terdaftar di <b style={{ color: 'var(--text)' }}>{t.name}</b></div>
            <div style={{ background: 'rgba(0,255,136,0.07)', border: '1px solid rgba(0,255,136,0.2)', borderRadius: 5, padding: 14, marginBottom: 20, fontSize: 13, color: 'var(--muted)', lineHeight: 1.7 }}>📱 Hubungi organizer untuk konfirmasi pembayaran <b style={{ color: 'var(--text)' }}>{fmtRp(t.entry)}</b></div>
            <button className="btn btn-ghost" onClick={() => setStep('detail')}>← Lihat Turnamen</button>
          </div>
        )}
      </div>
    </div>
  )
}

// ── SIDEBAR & NAV ─────────────────────────────────────────────────────────────
function Sidebar({ page, setPage, user, onLogout }) {
  const name = user?.user_metadata?.organizer_name || user?.email?.split('@')[0] || 'Organizer'
  return (
    <div className="sidebar">
      <div style={{ padding: '20px 16px 14px', borderBottom: '1px solid var(--border)' }}>
        <div style={{ fontFamily: 'var(--fh)', fontWeight: 900, fontSize: 16, color: 'var(--cyan)', letterSpacing: 2, animation: 'glow-pulse 3s infinite' }}>⚔ ARENAGG</div>
        <div style={{ fontSize: 9, color: 'var(--muted)', fontFamily: 'var(--fm)', marginTop: 2 }}>Tournament Platform</div>
      </div>
      <nav style={{ flex: 1, padding: '10px 6px', overflowY: 'auto' }}>
        {NAV.map(n => <button key={n.id} className={`nav-item ${page === n.id ? 'active' : ''}`} onClick={() => setPage(n.id)}><span className="nav-icon">{n.icon}</span><span>{n.label}</span></button>)}
      </nav>
      <div style={{ padding: '12px 14px', borderTop: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 10 }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg,var(--cyan),var(--orange))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 13, color: '#000', flexShrink: 0 }}>{name[0].toUpperCase()}</div>
          <div><div style={{ fontSize: 12, fontWeight: 600, lineHeight: 1.2 }}>{name}</div><div style={{ fontSize: 9, color: 'var(--green)', fontFamily: 'var(--fm)' }}><span className="live-dot" />ONLINE</div></div>
        </div>
        <button className="btn btn-dark btn-full btn-sm" onClick={onLogout}>Keluar</button>
      </div>
    </div>
  )
}

function BottomNav({ page, setPage }) {
  return <nav className="bottom-nav">{NAV.map(n => <button key={n.id} className={`bnav-item ${page === n.id ? 'active' : ''}`} onClick={() => setPage(n.id)}><span className="bnav-icon">{n.icon}</span><span>{n.label}</span></button>)}</nav>
}

// ── DASHBOARD ─────────────────────────────────────────────────────────────────
function Dashboard({ tournaments, teams, setPage, loading }) {
  const totalPrize = tournaments.reduce((s, t) => s + Number(t.prize), 0)
  const totalRev   = tournaments.reduce((s, t) => s + (Number(t.entry) * Number(t.registered || 0) * 0.15), 0)
  const totalP     = teams.reduce((s, t) => s + t.members, 0)
  const live       = tournaments.find(t => t.status === 'live')
  if (loading) return <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '80vh' }}><Spinner size={32} color="var(--cyan)" /></div>
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 960 }}>
      <div style={{ marginBottom: 20 }}><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700 }}>Dashboard</h1><p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 3 }}>Overview realtime</p></div>
      <div className="g4" style={{ marginBottom: 18 }}>
        <StatCard icon="🏆" label="Turnamen" value={tournaments.length} color="var(--cyan)" trend={12} />
        <StatCard icon="👥" label="Total Peserta" value={totalP} color="var(--green)" trend={8} />
        <StatCard icon="💰" label="Prize Pool" value={fmtRp(totalPrize)} color="var(--yellow)" trend={20} />
        <StatCard icon="📈" label="Komisi" value={fmtRp(totalRev)} color="var(--orange)" trend={15} />
      </div>
      {live && <div style={{ background: 'rgba(255,45,85,0.07)', border: '1px solid rgba(255,45,85,0.25)', borderRadius: 6, padding: '12px 16px', marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10 }}><span style={{ fontSize: 16 }}>🔴</span><div style={{ flex: 1 }}><div style={{ fontFamily: 'var(--fh)', fontSize: 11, color: 'var(--red)', letterSpacing: 1 }}>LIVE SEKARANG</div><div style={{ fontSize: 13, marginTop: 1 }}>{live.name}</div></div><span className="tag tag-live">LIVE</span></div>}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        <div className="card">
          <div style={{ fontFamily: 'var(--fh)', fontSize: 11, marginBottom: 14, color: 'var(--cyan)', letterSpacing: 1 }}>TURNAMEN AKTIF</div>
          {tournaments.filter(t => t.status !== 'closed').length === 0 ? <div style={{ fontSize: 13, color: 'var(--muted)' }}>Belum ada turnamen aktif</div> :
            tournaments.filter(t => t.status !== 'closed').map(t => <div key={t.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '8px 0', borderBottom: '1px solid var(--border)' }}><div><div style={{ fontWeight: 600, fontSize: 13 }}>{t.name}</div><div style={{ fontSize: 11, color: 'var(--muted)' }}>{t.game} · {t.city}</div></div><span className={`tag tag-${t.status}`}>{t.status}</span></div>)}
        </div>
        <div className="card">
          <div style={{ fontFamily: 'var(--fh)', fontSize: 11, marginBottom: 14, color: 'var(--cyan)', letterSpacing: 1 }}>PENDAPATAN</div>
          {[{ l: 'Komisi Entry', v: totalRev * 0.7, p: 70, c: 'var(--cyan)' }, { l: 'Sponsorship', v: totalRev * 0.2, p: 20, c: 'var(--orange)' }, { l: 'Premium', v: totalRev * 0.1, p: 10, c: 'var(--green)' }].map(r => <div key={r.l} style={{ marginBottom: 11 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, fontSize: 12 }}><span style={{ color: 'var(--muted)' }}>{r.l}</span><span style={{ fontFamily: 'var(--fm)', fontSize: 11 }}>{fmtRp(r.v)}</span></div><div className="pbar"><div className="pfill" style={{ width: `${r.p}%`, background: r.c }} /></div></div>)}
        </div>
      </div>
      <div className="card">
        <div style={{ fontFamily: 'var(--fh)', fontSize: 11, marginBottom: 12, color: 'var(--cyan)', letterSpacing: 1 }}>AKSI CEPAT</div>
        <div style={{ display: 'flex', gap: 9, flexWrap: 'wrap' }}>
          <button className="btn btn-cyan" onClick={() => setPage('create')}>＋ Buat Turnamen</button>
          <button className="btn btn-orange" onClick={() => setPage('revenue')}>📈 Komisi</button>
          <button className="btn btn-ghost" onClick={() => setPage('teams')}>👥 Peserta</button>
        </div>
      </div>
    </div>
  )
}

function TournamentList({ tournaments, updateT, deleteT, setPage, setEditT, toast, onPreview }) {
  const [filter, setF]    = useState('all')
  const [shareT, setShareT] = useState(null)
  const filtered = filter === 'all' ? tournaments : tournaments.filter(t => t.status === filter)
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 1000 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18, flexWrap: 'wrap', gap: 10 }}>
        <div><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700 }}>Turnamen</h1><p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 2 }}>{tournaments.length} total</p></div>
        <button className="btn btn-cyan" onClick={() => { setEditT(null); setPage('create') }}>＋ Buat</button>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
        {['all', 'active', 'live', 'closed', 'pending'].map(s => <button key={s} onClick={() => setF(s)} style={{ padding: '4px 12px', borderRadius: 3, border: '1px solid', cursor: 'pointer', fontFamily: 'var(--fm)', fontSize: 9, textTransform: 'uppercase', background: filter === s ? 'var(--cyan)' : 'transparent', color: filter === s ? '#000' : 'var(--muted)', borderColor: filter === s ? 'var(--cyan)' : 'var(--border)', transition: 'all 0.15s' }}>{s}</button>)}
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 11 }}>
        {filtered.map(t => {
          const pct = Math.round(((t.registered || 0) / t.slots) * 100)
          return (
            <div key={t.id} className="card" style={{ padding: 0, overflow: 'hidden' }}>
              <div style={{ display: 'flex', alignItems: 'stretch' }}>
                <div style={{ width: 4, background: t.status === 'live' ? 'var(--red)' : t.status === 'active' ? 'var(--cyan)' : t.status === 'pending' ? 'var(--yellow)' : 'var(--muted)', flexShrink: 0 }} />
                <div style={{ flex: 1, padding: '14px 16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8 }}>
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 3, flexWrap: 'wrap' }}><span style={{ fontFamily: 'var(--fh)', fontWeight: 700, fontSize: 14 }}>{t.name}</span><span className={`tag tag-${t.status}`}>{t.status}</span></div>
                      <div style={{ fontSize: 11, color: 'var(--muted)', display: 'flex', gap: 10, flexWrap: 'wrap' }}><span>🎮 {t.game}</span><span>📍 {t.city}</span><span>📅 {t.date}</span></div>
                    </div>
                    <div style={{ textAlign: 'right' }}><div style={{ fontFamily: 'var(--fh)', fontSize: 15, color: 'var(--yellow)', fontWeight: 700 }}>{fmtRp(t.prize)}</div><div style={{ fontSize: 11, color: 'var(--muted)' }}>Entry {fmtRp(t.entry)}</div></div>
                  </div>
                  <div style={{ marginTop: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 10, color: 'var(--muted)', marginBottom: 3 }}><span>Slot</span><span style={{ fontFamily: 'var(--fm)', color: pct >= 90 ? 'var(--red)' : 'var(--text)' }}>{t.registered || 0}/{t.slots}</span></div>
                    <div className="pbar" style={{ marginBottom: 10 }}><div className="pfill" style={{ width: `${pct}%`, background: pct >= 90 ? 'var(--red)' : pct >= 60 ? 'var(--orange)' : 'var(--cyan)' }} /></div>
                    <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => setShareT(t)}>🔗 Bagikan</button>
                      {t.status === 'pending' && <button className="btn btn-green btn-sm" onClick={() => updateT(t.id, { status: 'active' })}>✓ Aktif</button>}
                      {t.status === 'active' && <button className="btn btn-danger btn-sm" onClick={() => updateT(t.id, { status: 'live' })}>▶ Live</button>}
                      {t.status === 'live' && <button className="btn btn-dark btn-sm" onClick={() => updateT(t.id, { status: 'closed' })}>■ Tutup</button>}
                      <button className="btn btn-ghost btn-sm" onClick={() => { setEditT(t); setPage('create') }}>✏</button>
                      <button onClick={() => deleteT(t.id)} style={{ background: 'rgba(255,45,85,0.1)', border: '1px solid rgba(255,45,85,0.25)', borderRadius: 3, padding: '5px 10px', color: 'var(--red)', cursor: 'pointer', fontSize: 10 }}>🗑</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
        {filtered.length === 0 && <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--muted)' }}><div style={{ fontSize: 34, marginBottom: 10 }}>📭</div><div style={{ fontFamily: 'var(--fh)', fontSize: 12 }}>TIDAK ADA TURNAMEN</div></div>}
      </div>
      {shareT && <ShareModal t={shareT} onClose={() => setShareT(null)} toast={toast} onPreview={onPreview} />}
    </div>
  )
}

function CreateTournament({ addT, updateT, editData, setEditT, toast }) {
  const empty = { name: '', game: GAMES[0], prize: '', entry: '', slots: '16', format: FORMATS[0], date: '', city: '', description: '' }
  const [form, setForm] = useState(editData ? { ...editData, description: editData.description || '' } : empty)
  const [saving, setSaving] = useState(false)
  const set = k => e => setForm(f => ({ ...f, [k]: e.target.value }))
  useEffect(() => { setForm(editData ? { ...editData, description: editData.description || '' } : empty) }, [editData?.id])
  const submit = async () => {
    if (!form.name || !form.prize || !form.entry || !form.date || !form.city) { toast('Isi semua field wajib!', 'error'); return }
    setSaving(true)
    if (editData) await updateT(editData.id, { name: form.name, game: form.game, prize: Number(form.prize), entry: Number(form.entry), slots: Number(form.slots), format: form.format, date: form.date, city: form.city, description: form.description })
    else await addT({ name: form.name, game: form.game, prize: Number(form.prize), entry: Number(form.entry), slots: Number(form.slots), format: form.format, date: form.date, city: form.city, description: form.description, registered: 0, status: 'pending' })
    setForm(empty); setEditT(null); setSaving(false)
  }
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 660 }}>
      <div style={{ marginBottom: 18 }}><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700, color: 'var(--cyan)' }}>{editData ? '✏ EDIT' : '＋ BUAT TURNAMEN'}</h1></div>
      <div className="card">
        <div style={{ marginBottom: 13 }}><label>Nama Turnamen *</label><input value={form.name} onChange={set('name')} placeholder="ML Grand Prix Blitar" /></div>
        <div className="g2" style={{ marginBottom: 13 }}><div><label>Game</label><select value={form.game} onChange={set('game')}>{GAMES.map(g => <option key={g}>{g}</option>)}</select></div><div><label>Format</label><select value={form.format} onChange={set('format')}>{FORMATS.map(f => <option key={f}>{f}</option>)}</select></div></div>
        <div className="g2" style={{ marginBottom: 13 }}><div><label>Kota *</label><input value={form.city} onChange={set('city')} placeholder="Blitar" /></div><div><label>Tanggal *</label><input type="date" value={form.date} onChange={set('date')} /></div></div>
        <hr className="div" />
        <div className="g3" style={{ marginBottom: 13 }}><div><label>Prize Pool *</label><input type="number" value={form.prize} onChange={set('prize')} placeholder="2000000" /></div><div><label>Entry Fee/Tim *</label><input type="number" value={form.entry} onChange={set('entry')} placeholder="25000" /></div><div><label>Slot</label><select value={form.slots} onChange={set('slots')}>{[4, 8, 16, 32, 64].map(n => <option key={n}>{n}</option>)}</select></div></div>
        {form.prize && form.entry && <div style={{ background: 'var(--bg3)', borderRadius: 4, padding: '10px 13px', marginBottom: 13, fontSize: 12 }}><span>Total entry: <b style={{ color: 'var(--cyan)' }}>{fmtRp(Number(form.entry) * Number(form.slots))}</b></span> · <span>Komisi 15%: <b style={{ color: 'var(--orange)' }}>{fmtRp(Number(form.entry) * Number(form.slots) * 0.15)}</b></span></div>}
        <hr className="div" />
        <div style={{ marginBottom: 18 }}><label>Deskripsi</label><textarea rows={3} value={form.description} onChange={set('description')} placeholder="Syarat, aturan, dll..." style={{ resize: 'vertical' }} /></div>
        <div style={{ display: 'flex', gap: 9 }}>
          <button className="btn btn-cyan" onClick={submit} disabled={saving}>{saving ? <><Spinner size={13} color="#000" />Menyimpan...</> : editData ? '💾 Simpan' : '🚀 Buat'}</button>
          {editData && <button className="btn btn-ghost" onClick={() => { setEditT(null); setForm(empty) }}>Batal</button>}
        </div>
      </div>
    </div>
  )
}

function TeamsView({ teams, tournaments, addTeam, updateTeam, deleteTeam }) {
  const [selT, setSelT]     = useState('all')
  const [showAdd, setShowAdd] = useState(false)
  const [form, setForm]     = useState({ name: '', captain: '', contact: '', members: '5', paid: false, tournament_id: tournaments[0]?.id || '' })
  const [saving, setSaving] = useState(false)
  const filtered = selT === 'all' ? teams : teams.filter(t => t.tournament_id === selT)
  const submit = async () => {
    if (!form.name || !form.captain || !form.tournament_id) return
    setSaving(true)
    await addTeam({ name: form.name, captain: form.captain, contact: form.contact, members: Number(form.members), paid: form.paid, tournament_id: form.tournament_id })
    setShowAdd(false); setSaving(false)
    setForm({ name: '', captain: '', contact: '', members: '5', paid: false, tournament_id: tournaments[0]?.id || '' })
  }
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 1000 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18, flexWrap: 'wrap', gap: 10 }}>
        <div><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700 }}>Peserta & Tim</h1><p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 2 }}>{filtered.length} tim · {filtered.filter(t => t.paid).length} lunas</p></div>
        <button className="btn btn-cyan" onClick={() => setShowAdd(!showAdd)}>＋ Daftarkan Tim</button>
      </div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap' }}>
        <button onClick={() => setSelT('all')} style={{ padding: '4px 12px', borderRadius: 3, border: '1px solid', cursor: 'pointer', fontFamily: 'var(--fm)', fontSize: 9, textTransform: 'uppercase', background: selT === 'all' ? 'var(--cyan)' : 'transparent', color: selT === 'all' ? '#000' : 'var(--muted)', borderColor: selT === 'all' ? 'var(--cyan)' : 'var(--border)' }}>Semua</button>
        {tournaments.map(t => <button key={t.id} onClick={() => setSelT(t.id)} style={{ padding: '4px 12px', borderRadius: 3, border: '1px solid', cursor: 'pointer', fontFamily: 'var(--fm)', fontSize: 9, textTransform: 'uppercase', background: selT === t.id ? 'var(--cyan)' : 'transparent', color: selT === t.id ? '#000' : 'var(--muted)', borderColor: selT === t.id ? 'var(--cyan)' : 'var(--border)' }}>{t.name.split(' ').slice(0, 2).join(' ')}</button>)}
      </div>
      {showAdd && (
        <div className="card" style={{ marginBottom: 14, borderColor: 'var(--cyan)' }}>
          <div className="g2" style={{ marginBottom: 11 }}><div><label>Nama Tim *</label><input value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} placeholder="Alpha Squad" /></div><div><label>Kapten *</label><input value={form.captain} onChange={e => setForm(f => ({ ...f, captain: e.target.value }))} placeholder="Nama kapten" /></div></div>
          <div className="g3" style={{ marginBottom: 11 }}><div><label>No. HP</label><input value={form.contact} onChange={e => setForm(f => ({ ...f, contact: e.target.value }))} placeholder="08xx" /></div><div><label>Member</label><select value={form.members} onChange={e => setForm(f => ({ ...f, members: e.target.value }))}>{[1, 2, 3, 4, 5, 6].map(n => <option key={n}>{n}</option>)}</select></div><div><label>Turnamen *</label><select value={form.tournament_id} onChange={e => setForm(f => ({ ...f, tournament_id: e.target.value }))}>{tournaments.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div></div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9, marginBottom: 13 }}><input type="checkbox" checked={form.paid} onChange={e => setForm(f => ({ ...f, paid: e.target.checked }))} style={{ width: 14, height: 14, accentColor: 'var(--cyan)' }} /><span style={{ fontSize: 14 }}>Sudah bayar entry fee</span></div>
          <div style={{ display: 'flex', gap: 8 }}><button className="btn btn-cyan" onClick={submit} disabled={saving}>{saving ? <Spinner size={13} color="#000" /> : 'Daftarkan'}</button><button className="btn btn-ghost" onClick={() => setShowAdd(false)}>Batal</button></div>
        </div>
      )}
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 500 }}>
            <thead><tr style={{ borderBottom: '1px solid var(--border)' }}>{['Tim', 'Kapten', 'Kontak', 'Member', 'Turnamen', 'Bayar', 'Aksi'].map(h => <th key={h} style={{ padding: '10px 13px', textAlign: 'left', fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--muted)', letterSpacing: 1, textTransform: 'uppercase', fontWeight: 400 }}>{h}</th>)}</tr></thead>
            <tbody>
              {filtered.map((t, i) => {
                const tr = tournaments.find(x => x.id === t.tournament_id)
                return <tr key={t.id} style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)' }}>
                  <td style={{ padding: '10px 13px', fontWeight: 600, fontSize: 13 }}>{t.name}</td>
                  <td style={{ padding: '10px 13px', fontSize: 12, color: 'var(--muted)' }}>{t.captain}</td>
                  <td style={{ padding: '10px 13px', fontFamily: 'var(--fm)', fontSize: 11, color: 'var(--muted)' }}>{t.contact || '-'}</td>
                  <td style={{ padding: '10px 13px', textAlign: 'center', fontFamily: 'var(--fm)' }}>{t.members}</td>
                  <td style={{ padding: '10px 13px', fontSize: 11, color: 'var(--cyan)' }}>{tr?.name || '-'}</td>
                  <td style={{ padding: '10px 13px' }}><button onClick={() => updateTeam(t.id, { paid: !t.paid })} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16 }}>{t.paid ? '✅' : '⬜'}</button></td>
                  <td style={{ padding: '10px 13px' }}><button onClick={() => deleteTeam(t.id, t.tournament_id)} style={{ background: 'rgba(255,45,85,0.1)', border: '1px solid rgba(255,45,85,0.25)', borderRadius: 3, padding: '3px 9px', color: 'var(--red)', cursor: 'pointer', fontSize: 10 }}>Hapus</button></td>
                </tr>
              })}
            </tbody>
          </table>
          {filtered.length === 0 && <div style={{ textAlign: 'center', padding: 32, color: 'var(--muted)' }}>Belum ada tim</div>}
        </div>
      </div>
    </div>
  )
}

function Finance({ tournaments, teams }) {
  const rows = tournaments.map(t => { const p = teams.filter(x => x.tournament_id === t.id && x.paid).length; const g = p * Number(t.entry); return { ...t, paid: p, gross: g, commission: g * 0.15 } })
  const tG = rows.reduce((s, r) => s + r.gross, 0), tC = rows.reduce((s, r) => s + r.commission, 0)
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 1000 }}>
      <div style={{ marginBottom: 18 }}><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700 }}>Keuangan</h1></div>
      <div className="g3" style={{ marginBottom: 18 }}><StatCard icon="💵" label="Total Entry" value={fmtRp(tG)} color="var(--cyan)" /><StatCard icon="🏦" label="Komisi 15%" value={fmtRp(tC)} color="var(--orange)" /><StatCard icon="🎯" label="Selesai" value={tournaments.filter(t => t.status === 'closed').length} color="var(--green)" /></div>
      <div className="card" style={{ padding: 0, overflow: 'hidden' }}><div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse', minWidth: 480 }}><thead><tr style={{ borderBottom: '1px solid var(--border)' }}>{['Turnamen', 'Tim Bayar', 'Gross', 'Komisi', 'Status'].map(h => <th key={h} style={{ padding: '10px 13px', textAlign: 'left', fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--muted)', letterSpacing: 1, textTransform: 'uppercase', fontWeight: 400 }}>{h}</th>)}</tr></thead><tbody>{rows.map((r, i) => <tr key={r.id} style={{ borderBottom: '1px solid var(--border)', background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.01)' }}><td style={{ padding: '10px 13px', fontWeight: 600, fontSize: 13 }}>{r.name}</td><td style={{ padding: '10px 13px', textAlign: 'center' }}>{r.paid}/{r.registered || 0}</td><td style={{ padding: '10px 13px', fontFamily: 'var(--fm)', fontSize: 12, color: 'var(--cyan)' }}>{fmtRp(r.gross)}</td><td style={{ padding: '10px 13px', fontFamily: 'var(--fm)', fontSize: 12, color: 'var(--orange)' }}>{fmtRp(r.commission)}</td><td style={{ padding: '10px 13px' }}><span className={`tag tag-${r.status}`}>{r.status}</span></td></tr>)}</tbody><tfoot><tr style={{ borderTop: '2px solid var(--border)' }}><td colSpan={2} style={{ padding: '10px 13px', fontFamily: 'var(--fh)', fontSize: 10, color: 'var(--cyan)' }}>TOTAL</td><td style={{ padding: '10px 13px', fontFamily: 'var(--fm)', fontSize: 12, fontWeight: 700, color: 'var(--cyan)' }}>{fmtRp(tG)}</td><td style={{ padding: '10px 13px', fontFamily: 'var(--fm)', fontSize: 12, fontWeight: 700, color: 'var(--orange)' }}>{fmtRp(tC)}</td><td /></tr></tfoot></table></div></div>
    </div>
  )
}

function RevenuePage({ tournaments, teams, toast }) {
  const [showWd, setShowWd] = useState(false)
  const [wdAmt, setWdAmt]   = useState('')
  const [wdH, setWdH]       = useState([{ id: 'w1', date: '2026-05-28', amount: 450000, status: 'cair', method: 'BCA 1234xxxx' }])
  const rows = tournaments.map(t => { const p = teams.filter(x => x.tournament_id === t.id && x.paid).length; const g = p * Number(t.entry); return { ...t, comm: g * 0.15, sp: t.status === 'closed' ? Number(t.prize) * 0.08 : 0, pr: t.status !== 'pending' ? 50000 : 0 } })
  const tC = rows.reduce((s, r) => s + r.comm, 0), tSp = rows.reduce((s, r) => s + r.sp, 0), tPr = rows.reduce((s, r) => s + r.pr, 0)
  const grand = tC + tSp + tPr, totalWd = wdH.reduce((s, w) => s + w.amount, 0), saldo = grand - totalWd
  const doWd = () => { const a = Number(wdAmt); if (!a || a < 10000) { toast('Min Rp10.000', 'error'); return } if (a > saldo) { toast('Saldo tidak cukup!', 'error'); return } setWdH(p => [{ id: uid(), date: new Date().toISOString().slice(0, 10), amount: a, status: 'proses', method: 'BCA 1234xxxx' }, ...p]); toast(`Withdraw ${fmtRp(a)} diproses! 💸`, 'success'); setWdAmt(''); setShowWd(false) }
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 1000 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
        <div><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700, color: 'var(--cyan)' }}>📈 LAPORAN KOMISI</h1><p style={{ color: 'var(--muted)', fontSize: 13, marginTop: 2 }}>Pendapatan realtime</p></div>
        <button className="btn btn-orange" onClick={() => setShowWd(true)}>💸 Withdraw</button>
      </div>
      <div style={{ background: 'linear-gradient(135deg,rgba(0,229,255,0.1),rgba(255,107,0,0.08))', border: '1px solid rgba(0,229,255,0.3)', borderRadius: 8, padding: 22, marginBottom: 18, position: 'relative' }}>
        <div style={{ position: 'absolute', top: 10, right: 12, fontSize: 10, fontFamily: 'var(--fm)', color: 'var(--cyan)' }}><span className="live-dot" />LIVE</div>
        <div style={{ fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--muted)', letterSpacing: 2, marginBottom: 6 }}>SALDO TERSEDIA</div>
        <div style={{ fontFamily: 'var(--fh)', fontSize: 30, fontWeight: 900, color: 'var(--cyan)', marginBottom: 3 }}>{fmtRp(saldo)}</div>
        <div style={{ fontSize: 12, color: 'var(--muted)' }}>Masuk: <span style={{ color: 'var(--green)' }}>{fmtRp(grand)}</span> · Dicairkan: <span style={{ color: 'var(--orange)' }}>{fmtRp(totalWd)}</span></div>
      </div>
      <div className="g4" style={{ marginBottom: 18 }}>
        <StatCard icon="🎫" label="Komisi Entry" value={fmtRp(tC)} color="var(--cyan)" />
        <StatCard icon="🏅" label="Sponsorship" value={fmtRp(tSp)} color="var(--orange)" />
        <StatCard icon="⭐" label="Premium" value={fmtRp(tPr)} color="var(--green)" />
        <StatCard icon="📊" label="Turnamen" value={tournaments.length} color="var(--yellow)" />
      </div>
      <div className="card" style={{ marginBottom: 16 }}>
        <div style={{ fontFamily: 'var(--fh)', fontSize: 11, marginBottom: 14, color: 'var(--cyan)', letterSpacing: 1 }}>KOMISI PER TURNAMEN</div>
        {rows.length === 0 && <div style={{ color: 'var(--muted)', fontSize: 13 }}>Buat turnamen pertamamu!</div>}
        {[...rows].sort((a, b) => (b.comm + b.sp + b.pr) - (a.comm + a.sp + a.pr)).map((r, i) => {
          const total = r.comm + r.sp + r.pr
          const mx = rows.reduce((m, x) => Math.max(m, x.comm + x.sp + x.pr), 1)
          return <div key={r.id} style={{ marginBottom: 12 }}><div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4, flexWrap: 'wrap', gap: 6 }}><div style={{ display: 'flex', gap: 8, alignItems: 'center' }}><span style={{ fontFamily: 'var(--fm)', fontSize: 10, color: i === 0 ? 'var(--yellow)' : 'var(--muted)', width: 14 }}>#{i + 1}</span><div><div style={{ fontSize: 13, fontWeight: 600 }}>{r.name}</div><div style={{ fontSize: 10, color: 'var(--muted)' }}>{r.game} · {r.city}</div></div></div><div style={{ fontFamily: 'var(--fm)', fontSize: 12, color: 'var(--cyan)' }}>{fmtRp(total)}</div></div><div className="pbar"><div className="pfill" style={{ width: `${(total / mx) * 100}%`, background: i === 0 ? 'var(--yellow)' : 'var(--cyan)' }} /></div></div>
        })}
      </div>
      {showWd && <div className="overlay" onClick={e => { if (e.target === e.currentTarget) setShowWd(false) }}><div className="modal" style={{ maxWidth: 400 }}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}><div style={{ fontFamily: 'var(--fh)', fontSize: 13, color: 'var(--orange)', letterSpacing: 1 }}>💸 WITHDRAW</div><button onClick={() => setShowWd(false)} style={{ background: 'none', border: 'none', color: 'var(--muted)', cursor: 'pointer', fontSize: 20 }}>×</button></div><div style={{ background: 'var(--bg3)', borderRadius: 4, padding: '12px 14px', marginBottom: 14 }}><div style={{ fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--muted)', marginBottom: 3 }}>SALDO</div><div style={{ fontFamily: 'var(--fh)', fontSize: 22, color: 'var(--cyan)', fontWeight: 700 }}>{fmtRp(saldo)}</div></div><div style={{ marginBottom: 13 }}><label>Jumlah (Rp)</label><input type="number" value={wdAmt} onChange={e => setWdAmt(e.target.value)} placeholder="Min Rp 10.000" /></div><div style={{ marginBottom: 18 }}><label>Rekening</label><input value="BCA 1234xxxx" readOnly style={{ color: 'var(--muted)' }} /></div><div style={{ display: 'flex', gap: 9 }}><button className="btn btn-orange btn-full" onClick={doWd}>💸 Cairkan</button><button className="btn btn-ghost" onClick={() => setShowWd(false)}>Batal</button></div></div></div>}
    </div>
  )
}

function BracketView({ tournaments, teams }) {
  const [selT, setSelT] = useState(tournaments[0]?.id || '')
  const t = tournaments.find(x => x.id === selT)
  const tTeams = teams.filter(x => x.tournament_id === selT)
  const pairs = []
  for (let i = 0; i < Math.min(tTeams.length, 8); i += 2) pairs.push({ a: tTeams[i], b: tTeams[i + 1], w: Math.random() > 0.5 ? tTeams[i]?.id : tTeams[i + 1]?.id })
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 1000 }}>
      <div style={{ marginBottom: 18 }}><h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700 }}>Bracket</h1></div>
      <div style={{ display: 'flex', gap: 6, marginBottom: 16, flexWrap: 'wrap' }}>{tournaments.map(x => <button key={x.id} onClick={() => setSelT(x.id)} style={{ padding: '6px 14px', borderRadius: 4, cursor: 'pointer', fontSize: 12, fontWeight: 500, background: selT === x.id ? 'var(--cyan)' : 'var(--panel)', color: selT === x.id ? '#000' : 'var(--text)', border: `1px solid ${selT === x.id ? 'var(--cyan)' : 'var(--border)'}`, transition: 'all 0.15s' }}>{x.name}</button>)}</div>
      {t && (<>
        <div className="card" style={{ marginBottom: 16 }}><div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}><div><div style={{ fontFamily: 'var(--fh)', fontSize: 15, fontWeight: 700, color: 'var(--cyan)' }}>{t.name}</div><div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 3 }}>{t.game} · {t.format}</div></div><div><div style={{ fontFamily: 'var(--fh)', fontSize: 18, color: 'var(--yellow)' }}>{fmtRp(t.prize)}</div></div></div></div>
        {tTeams.length < 2 ? <div className="card" style={{ textAlign: 'center', padding: 40, color: 'var(--muted)' }}><div style={{ fontSize: 34, marginBottom: 10 }}>📊</div><div style={{ fontFamily: 'var(--fh)', fontSize: 12 }}>MIN. 2 TIM</div></div> : (
          <div style={{ display: 'flex', gap: 32, overflowX: 'auto', paddingBottom: 14, alignItems: 'flex-start' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18, flexShrink: 0 }}>{pairs.map((p, i) => <div key={i}><div style={{ fontSize: 9, fontFamily: 'var(--fm)', color: 'var(--muted)', marginBottom: 4 }}>MATCH {i + 1}</div><div className="b-match"><div className={`b-team ${p.w === p.a?.id ? 'winner' : 'loser'}`}><span>{p.a?.name || 'BYE'}</span>{p.w === p.a?.id && <span>🏆</span>}</div><div className={`b-team ${p.w === p.b?.id ? 'winner' : 'loser'}`}><span>{p.b?.name || 'BYE'}</span>{p.w === p.b?.id && <span>🏆</span>}</div></div></div>)}</div>
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', flexShrink: 0, paddingTop: 60 }}><div style={{ fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--yellow)', marginBottom: 4 }}>🏆 GRAND FINAL</div><div className="b-match" style={{ border: '1px solid rgba(255,215,0,0.3)' }}><div className="b-team" style={{ color: 'var(--muted)' }}><span>TBD</span></div><div className="b-team" style={{ color: 'var(--muted)' }}><span>TBD</span></div></div><div style={{ textAlign: 'center', marginTop: 8, fontSize: 12, fontFamily: 'var(--fh)', color: 'var(--yellow)' }}>{fmtRp(t.prize)}</div></div>
          </div>
        )}
      </>)}
    </div>
  )
}

function Settings({ user }) {
  const name = user?.user_metadata?.organizer_name || user?.email?.split('@')[0] || 'Organizer'
  return (
    <div className="animate-in" style={{ padding: 24, maxWidth: 600 }}>
      <h1 style={{ fontFamily: 'var(--fh)', fontSize: 19, fontWeight: 700, marginBottom: 18 }}>Pengaturan</h1>
      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--cyan)', marginBottom: 14, letterSpacing: 2 }}>AKUN ORGANIZER</div>
        <div style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <div style={{ width: 44, height: 44, borderRadius: '50%', background: 'linear-gradient(135deg,var(--cyan),var(--orange))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 18, color: '#000' }}>{name[0].toUpperCase()}</div>
          <div><div style={{ fontWeight: 700, fontSize: 15 }}>{name}</div><div style={{ fontSize: 12, color: 'var(--muted)', marginTop: 2 }}>{user?.email}</div><div style={{ fontSize: 11, color: 'var(--green)', marginTop: 4 }}>✓ Terhubung ke Supabase</div></div>
        </div>
      </div>
      <div className="card">
        <div style={{ fontFamily: 'var(--fm)', fontSize: 9, color: 'var(--yellow)', marginBottom: 12, letterSpacing: 2 }}>EKSPANSI SEA</div>
        {[{ flag: '🇮🇩', country: 'Indonesia', status: 'active', note: 'Pasar utama' }, { flag: '🇵🇭', country: 'Philippines', status: 'soon', note: 'Q3 2026' }, { flag: '🇻🇳', country: 'Vietnam', status: 'soon', note: 'Q4 2026' }, { flag: '🇹🇭', country: 'Thailand', status: 'soon', note: '2027' }].map(c => (
          <div key={c.country} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '9px 12px', background: 'var(--bg3)', borderRadius: 4, marginBottom: 7 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}><span style={{ fontSize: 18 }}>{c.flag}</span><div><div style={{ fontWeight: 600, fontSize: 13 }}>{c.country}</div><div style={{ fontSize: 11, color: 'var(--muted)' }}>{c.note}</div></div></div>
            <span className={`tag ${c.status === 'active' ? 'tag-active' : 'tag-pending'}`}>{c.status === 'active' ? 'AKTIF' : 'SEGERA'}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── APP ROOT ──────────────────────────────────────────────────────────────────
export default function App() {
  const [user,    setUser]    = useState(null)
  const [loading, setLoading] = useState(true)
  const [page,    setPage]    = useState('dashboard')
  const [editT,   setEditT]   = useState(null)
  const [pubTid,  setPubTid]  = useState(null)
  const [toasts,  setToasts]  = useState([])

  const toast = useCallback((msg, type = 'info') => {
    const id = uid()
    setToasts(p => [...p, { id, msg, type }])
    setTimeout(() => setToasts(p => p.filter(t => t.id !== id)), 3200)
  }, [])

  // Hash routing untuk halaman publik
  useEffect(() => {
    const parse = () => { const m = window.location.hash.match(/^\/?#?\/daftar\/(.+)$|^#\/daftar\/(.+)$/); setPubTid(m ? (m[1] || m[2]) : null) }
    parse()
    window.addEventListener('hashchange', parse)
    return () => window.removeEventListener('hashchange', parse)
  }, [])

  // Auth state listener
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setUser(data.session?.user || null)
      setLoading(false)
    })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user || null)
    })
    return () => subscription.unsubscribe()
  }, [])

  const { tournaments, teams, loading: dataLoading, addT, updateT, deleteT, addTeam, updateTeam, deleteTeam } = useData(user?.id, toast)

  useEffect(() => { if (page !== 'create') setEditT(null) }, [page])

  const logout = async () => { await supabase.auth.signOut(); setUser(null) }

  // Public page — tidak perlu login
  if (pubTid !== null) return (
    <>
      <PublicPage tid={pubTid} onBack={() => { window.location.hash = '' }} toast={toast} />
      <Toasts list={toasts} />
    </>
  )

  if (loading) return <div style={{ minHeight: '100vh', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><div style={{ textAlign: 'center' }}><div style={{ fontFamily: 'var(--fh)', fontSize: 20, color: 'var(--cyan)', letterSpacing: 3, animation: 'glow-pulse 2s infinite', marginBottom: 16 }}>⚔ ARENAGG</div><Spinner size={28} color="var(--cyan)" /></div></div>

  if (!user) return <><AuthPage onLogin={u => setUser(u)} /><Toasts list={toasts} /></>

  const props = { tournaments, teams, loading: dataLoading, setPage, editData: editT, setEditT, toast, user, addT, updateT, deleteT, addTeam, updateTeam, deleteTeam, onPreview: id => { window.location.hash = `/daftar/${id}` } }

  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg)' }}>
      <Sidebar page={page} setPage={setPage} user={user} onLogout={logout} />
      <main style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden' }}>
        {page === 'dashboard'   && <Dashboard    {...props} />}
        {page === 'revenue'     && <RevenuePage  {...props} />}
        {page === 'tournaments' && <TournamentList {...props} />}
        {page === 'create'      && <CreateTournament addT={addT} updateT={updateT} editData={editT} setEditT={setEditT} toast={toast} />}
        {page === 'teams'       && <TeamsView    {...props} />}
        {page === 'bracket'     && <BracketView  {...props} />}
        {page === 'finance'     && <Finance      {...props} />}
        {page === 'settings'    && <Settings     user={user} />}
      </main>
      <BottomNav page={page} setPage={setPage} />
      <Toasts list={toasts} />
    </div>
  )
}
